'use client'

import { useState, useRef } from 'react'
import html2canvas from 'html2canvas'
import jsPDF from 'jspdf'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Progress } from '@/components/ui/progress'
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group'
import { Badge } from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'

// MBTI Questions for Kids
const mbtiQuestions = [
  // E vs I questions
  { id: 1, dimension: 'EI', text: "Ketika ada acara sekolah, kamu lebih suka:", optionA: "Bergabung dengan semua teman dan ikut bermain", optionB: "Duduk tenang dan mengamati dari kejauhan" },
  { id: 2, dimension: 'EI', text: "Ketika belajar kelompok, kamu lebih suka:", optionA: "Berdiskusi aktif dengan teman-teman", optionB: "Berpikir sendiri dulu sebelum berbicara" },
  { id: 3, dimension: 'EI', text: "Di waktu luang, kamu lebih suka:", optionA: "Bermain bersama teman-teman", optionB: "Melakukan kegiatan sendiri" },
  { id: 4, dimension: 'EI', text: "Ketika bertemu orang baru, kamu biasanya:", optionA: "Mudah mengobrol dan berteman", optionB: "Menunggu orang lain mengajak bicara" },
  { id: 5, dimension: 'EI', text: "Di kelas, kamu lebih suka:", optionA: "Ikut aktif dalam diskusi kelas", optionB: "Mendengarkan dan mencatat" },
  { id: 6, dimension: 'EI', text: "Ketika ada masalah, kamu lebih suka:", optionA: "Bicara dengan teman untuk mencari solusi", optionB: "Berpikir sendiri dulu" },
  { id: 7, dimension: 'EI', text: "Di pesta ulang tahun, kamu biasanya:", optionA: "Bergabung dalam permainan dan ramah", optionB: "Memilih beberapa teman dekat untuk diajak bicara" },
  { id: 8, dimension: 'EI', text: "Ketika guru bertanya, kamu cenderung:", optionA: "Langsung mengangkat tangan", optionB: "Berpikir dulu baru menjawab" },
  { id: 9, dimension: 'EI', text: "Dalam tim olahraga, kamu lebih suka:", optionA: "Menjadi kapten dan memimpin", optionB: "Menjadi pendukung yang baik" },
  { id: 10, dimension: 'EI', text: "Ketika liburan, kamu lebih suka:", optionA: "Bepergian ke tempat ramai", optionB: "Beristirahat di rumah" },
  
  // S vs N questions
  { id: 11, dimension: 'SN', text: "Ketika belajar sesuatu yang baru, kamu lebih suka:", optionA: "Langsung praktek dan coba-coba", optionB: "Mendengarkan penjelasan teorinya dulu" },
  { id: 12, dimension: 'SN', text: "Ketika membaca cerita, kamu lebih suka:", optionA: "Cerita yang nyata dan bisa terjadi", optionB: "Cerita fantasi dengan imajinasi" },
  { id: 13, dimension: 'SN', text: "Dalam mengerjakan tugas, kamu lebih suka:", optionA: "Mengikuti instruksi langkah demi langkah", optionB: "Mencoba cara kreatif sendiri" },
  { id: 14, dimension: 'SN', text: "Ketika guru menjelaskan, kamu lebih suka:", optionA: "Contoh nyata yang bisa dilihat", optionB: "Ide-ide besar dan konsep" },
  { id: 15, dimension: 'SN', text: "Dalam bermain, kamu lebih suka:", optionA: "Permainan dengan aturan jelas", optionB: "Permainan yang bisa dikreasikan" },
  { id: 16, dimension: 'SN', text: "Ketika melihat gambar, kamu lebih perhatikan:", optionA: "Detail-detail kecil dalam gambar", optionB: "Ide atau kesan keseluruhan" },
  { id: 17, dimension: 'SN', text: "Dalam belajar matematika, kamu lebih suka:", optionA: "Soal yang bisa dihitung langsung", optionB: "Soal yang butuh pemikiran abstrak" },
  { id: 18, dimension: 'SN', text: "Ketika belajar IPA, kamu lebih suka:", optionA: "Praktikum dan eksperimen", optionB: "Teori dan konsep ilmiah" },
  { id: 19, dimension: 'SN', text: "Dalam menggambar, kamu lebih suka:", optionA: "Menggambar objek nyata", optionB: "Menggambar imajinasi" },
  { id: 20, dimension: 'SN', text: "Ketika belajar sejarah, kamu lebih suka:", optionA: "Fakta-fakta dan tanggal penting", optionB: "Kisah dan maknanya" },
  
  // T vs F questions
  { id: 21, dimension: 'TF', text: "Ketika teman bertengkar, kamu cenderung:", optionA: "Mencari siapa yang benar dan salah", optionB: "Mencoba menenangkan keduanya" },
  { id: 22, dimension: 'TF', text: "Dalam memilih teman, kamu lebih suka:", optionA: "Teman yang pintar dan logis", optionB: "Teman yang baik hati dan perhatian" },
  { id: 23, dimension: 'TF', text: "Ketika ada aturan yang tidak adil, kamu:", optionA: "Mencari alasan logis mengapa harus diikuti", optionB: "Merasa sedih untuk yang dirugikan" },
  { id: 24, dimension: 'TF', text: "Dalam memberi komentar, kamu lebih suka:", optionA: "Memberi saran yang objektif", optionB: "Memberi dukungan dan semangat" },
  { id: 25, dimension: 'TF', text: "Ketika menilai hasil kerja, kamu lebih lihat:", optionA: "Kualitas dan kebenaran hasilnya", optionB: "Usaha dan perasaan yang diberikan" },
  { id: 26, dimension: 'TF', text: "Dalam mengambil keputusan, kamu lebih suka:", optionA: "Berdasarkan logika dan fakta", optionB: "Berdasarkan perasaan dan nilai-nilai" },
  { id: 27, dimension: 'TF', text: "Ketika teman sedih, kamu cenderung:", optionA: "Mencari solusi untuk masalahnya", optionB: "Mendengarkan dan menemani" },
  { id: 28, dimension: 'TF', text: "Dalam berdebat, kamu lebih suka:", optionA: "Membuktikan bahwa pendapatmu benar", optionB: "Mencari titik temu yang adil" },
  { id: 29, dimension: 'TF', text: "Ketika melihat ketidakadilan, kamu:", optionA: "Menganalisis penyebabnya", optionB: "Merasa ikut terharu" },
  { id: 30, dimension: 'TF', text: "Dalam memberi kritik, kamu lebih suka:", optionA: "Langsung to the point dan jujur", optionB: "Berbicara dengan lembut dan hati-hati" },
  
  // J vs P questions
  { id: 31, dimension: 'JP', text: "Ketika mengerjakan PR, kamu biasanya:", optionA: "Membuat jadwal dan mengikuti rencana", optionB: "Mengerjakan sesuai mood dan inspirasi" },
  { id: 32, dimension: 'JP', text: "Ketika membersihkan kamar, kamu lebih suka:", optionA: "Membersihkan secara teratur dan terjadwal", optionB: "Membersihkan ketika terlihat berantakan" },
  { id: 33, dimension: 'JP', text: "Dalam merencanakan liburan, kamu lebih suka:", optionA: "Membuat itinerary detail", optionB: "Spontan dan fleksibel" },
  { id: 34, dimension: 'JP', text: "Ketika ada tugas baru, kamu cenderung:", optionA: "Mengerjakan secepat mungkin", optionB: "Menunda hingga dekat deadline" },
  { id: 35, dimension: 'JP', text: "Dalam bermain, kamu lebih suka:", optionA: "Permainan dengan aturan dan tujuan jelas", optionB: "Permainan bebas tanpa aturan ketat" },
  { id: 36, dimension: 'JP', text: "Ketika belajar, kamu lebih suka:", optionA: "Membuat jadwal belajar teratur", optionB: "Belajar sesuai kebutuhan" },
  { id: 37, dimension: 'JP', text: "Dalam mengatur barang, kamu lebih suka:", optionA: "Semua barang ada tempatnya", optionB: "Fleksibel dan tidak terlalu rapi" },
  { id: 38, dimension: 'JP', text: "Ketika ada banyak tugas, kamu:", optionA: "Membuat daftar dan mengerjakan satu per satu", optionB: "Mengerjakan yang paling menarik dulu" },
  { id: 39, dimension: 'JP', text: "Dalam memilih pakaian, kamu biasanya:", optionA: "Sudah menyiapkan dari malam sebelumnya", optionB: "Memilih saat akan berangkat" },
  { id: 40, dimension: 'JP', text: "Ketika ada perubahan rencana, kamu:", optionA: "Merasa tidak nyaman dan bingung", optionB: "Menikmati perubahan dan fleksibel" }
]

// VAK Learning Style Questions
const vakQuestions = [
  // Visual questions
  { id: 1, style: 'V', text: "Saya lebih mudah belajar dengan melihat gambar atau diagram" },
  { id: 2, style: 'V', text: "Saya suka menggunakan warna-warna untuk membantu belajar" },
  { id: 3, style: 'V', text: "Saya lebih mudah mengingat informasi yang saya baca" },
  { id: 4, style: 'V', text: "Saya suka membuat catatan dengan tulisan yang rapi" },
  { id: 5, style: 'V', text: "Saya lebih suka belajar dari video daripada audio" },
  { id: 6, style: 'V', text: "Saya suka menggunakan flashcard untuk belajar" },
  { id: 7, style: 'V', text: "Saya mudah terganggu oleh lingkungan yang berantakan" },
  { id: 8, style: 'V', text: "Saya suka membuat mind map atau diagram alir" },
  { id: 9, style: 'V', text: "Saya lebih mudah mengingat wajah daripada nama" },
  { id: 10, style: 'V', text: "Saya suka belajar dengan melihat demonstrasi" },
  
  // Auditory questions
  { id: 11, style: 'A', text: "Saya lebih mudah belajar dengan mendengarkan penjelasan" },
  { id: 12, style: 'A', text: "Saya suka belajar sambil mendengarkan musik" },
  { id: 13, style: 'A', text: "Saya lebih mudah mengingat apa yang saya dengar daripada yang saya baca" },
  { id: 14, style: 'A', text: "Saya suka membaca pelajaran dengan suara keras" },
  { id: 15, style: 'A', text: "Saya lebih suka diskusi kelompok daripada belajar sendiri" },
  { id: 16, style: 'A', text: "Saya suka merekam penjelasan guru untuk didengarkan lagi" },
  { id: 17, style: 'A', text: "Saya mudah terganggu oleh suara bising" },
  { id: 18, style: 'A', text: "Saya lebih mudah mengingat nama daripada wajah" },
  { id: 19, style: 'A', text: "Saya suka belajar dengan mengulang-ulang pelajaran dengan suara keras" },
  { id: 20, style: 'A', text: "Saya lebih suka penjelasan lisan daripada tertulis" },
  
  // Kinesthetic questions
  { id: 21, style: 'K', text: "Saya lebih mudah belajar dengan praktek langsung" },
  { id: 22, style: 'K', text: "Saya suka bergerak saat belajar" },
  { id: 23, style: 'K', text: "Saya lebih mudah mengingat dengan melakukan sesuatu" },
  { id: 24, style: 'K', text: "Saya suka belajar sambil bermain" },
  { id: 25, style: 'K', text: "Saya lebih suka proyek tangan daripada tes tertulis" },
  { id: 26, style: 'K', text: "Saya suka menggunakan alat peraga saat belajar" },
  { id: 27, style: 'K', text: "Saya mudah bosan jika duduk terlalu lama" },
  { id: 28, style: 'K', text: "Saya lebih suka belajar dengan eksperimen" },
  { id: 29, style: 'K', text: "Saya suai belajar sambil melakukan gerakan tubuh" },
  { id: 30, style: 'K', text: "Saya lebih mudah mengingat dengan mencoba langsung" }
]

// Enhanced MBTI Type Descriptions with professions and detailed information
const mbtiDescriptions: Record<string, { 
  title: string; 
  description: string; 
  detailedDescription: string;
  strengths: string[];
  challenges: string[];
  professions: string[];
  learning: string; 
  detailedLearning: string;
  learningRecommendations: string[];
  color: string;
  emoji: string;
}> = {
  'ISTJ': {
    title: 'Penyelenggara yang Andal',
    description: 'Anak yang tenang, serius, bertanggung jawab, dan suka mengikuti aturan. Kamu sangat dapat diandalkan dan selalu menepati janji.',
    detailedDescription: 'Kamu adalah anak yang sangat terorganisir dan bertanggung jawab. Kamu suka memiliki rutinitas yang jelas dan merasa nyaman ketika segala sesuatu teratur. Kamu adalah teman yang setia dan selalu bisa diandalkan untuk menepati janji.',
    strengths: ['Sangat terorganisir', 'Bertanggung jawab', 'Dapat diandalkan', 'Jujur dan lurus', 'Pekerja keras'],
    challenges: ['Kaku terhadap perubahan', 'Terlalu serius', 'Sulit beradaptasi', 'Kurang fleksibel'],
    professions: ['Akuntan', 'Pengacara', 'Dokter', 'Insinyur', 'Manajer', 'Guru', 'Penerbang', 'Analisis Keuangan'],
    learning: 'Belajar dengan langkah-langkah yang jelas, praktik langsung, dan contoh nyata. Buat jadwal belajar teratur.',
    detailedLearning: 'Kamu adalah tipe learner yang membutuhkan struktur yang jelas dan terorganisir. Kamu belajar paling baik ketika diberikan instruksi langkah demi langkah, contoh nyata, dan kesempatan untuk praktik langsung.',
    learningRecommendations: [
      'Buat jadwal belajar harian yang teratur',
      'Gunakan checklist untuk melacak kemajuan',
      'Pelajari konsep dengan contoh konkret',
      'Praktikkan langsung apa yang dipelajari',
      'Buat catatan yang terstruktur dan rapi',
      'Gunakan timer untuk manajemen waktu',
      'Fokus pada satu topik dalam satu waktu'
    ],
    color: 'from-blue-400 to-blue-600',
    emoji: '📋'
  },
  'ISFJ': {
    title: 'Pelindung yang Penuh Kasih',
    description: 'Anak yang hangat, perhatian, suka membantu orang lain, dan setia. Kamu peduli dengan perasaan teman-teman.',
    detailedDescription: 'Kamu adalah anak yang sangat peduli dan perhatian pada orang lain. Kamu selalu siap membantu teman yang kesulitan dan sangat setia pada pertemanan. Kamu memiliki ingatan yang baik tentang detail-detail penting tentang orang yang kamu sayangi.',
    strengths: ['Sangat perhatian', 'Setia dan loyal', 'Pekerja keras', 'Praktis', 'Baik hati'],
    challenges: ['Mengabaikan kebutuhan sendiri', 'Terlalu pasif', 'Sulit berkata tidak', 'Terlalu sensitif'],
    professions: ['Perawat', 'Guru', 'Psikolog', 'Pekerja Sosial', 'Dokter Gigi', 'Ahli Gizi', 'Pustakawan', 'Terapis'],
    learning: 'Belajar dalam lingkungan yang nyaman, dengan dukungan guru, dan fokus pada bagaimana ilmu membantu orang lain.',
    detailedLearning: 'Kamu belajar paling baik dalam lingkungan yang mendukung dan harmonis. Kamu perlu merasa nyaman dan dihargai untuk bisa belajar dengan optimal. Hubungan personal dengan guru penting bagimu.',
    learningRecommendations: [
      'Carilah guru yang hangat dan suportif',
      'Belajar dalam kelompok kecil yang harmonis',
      'Hubungkan pelajaran dengan membantu orang lain',
      'Gunakan contoh-contoh yang relevan dengan kehidupan',
      'Buat jurnal belajar pribadi',
      'Berikan reward pada diri sendiri',
      'Belajar dengan teman yang bisa diajak bincang'
    ],
    color: 'from-green-400 to-green-600',
    emoji: '🤝'
  },
  'INFJ': {
    title: 'Pembimbing yang Bijaksana',
    description: 'Anak yang pendiam, intuitif, punya visi, dan peduli dengan orang lain. Kamu punya pemikiran yang mendalam.',
    detailedDescription: 'Kamu adalah anak yang memiliki pemikiran mendalam dan visi yang kuat tentang masa depan. Kamu sangat peduli dengan orang lain dan selalu ingin membantu mereka menjadi versi terbaik diri mereka. Kamu memiliki intuisi yang tajam.',
    strengths: ['Memiliki visi', 'Sangat peduli', 'Kreatif', 'Intuitif', 'Bijaksana'],
    challenges: ['Terlalu idealis', 'Sulit menerima kritik', 'Terlalu sensitif', 'Cenderung menyendiri'],
    professions: ['Psikolog', 'Penulis', 'Konselor', 'Guru', 'Pekerja Sosial', 'Desainer', 'Filsuf', 'Peneliti'],
    learning: 'Belajar dengan memahami makna di balik fakta, diskusi tentang ide-ide besar, dan proyek yang membantu orang.',
    detailedLearning: 'Kamu adalah learner yang conceptual dan global. Kamu perlu memahami makna dan tujuan di balik apa yang kamu pelajari. Hubungan antar konsep lebih penting daripada detail-detail kecil.',
    learningRecommendations: [
      'Pelajari "mengapa" sebelum "bagaimana"',
      'Gunakan mind map untuk melihat hubungan konsep',
      'Diskusikan ide-ide besar dengan guru atau teman',
      'Buat proyek yang memiliki dampak sosial',
      'Tulis refleksi tentang apa yang dipelajari',
      'Gunakan metafora dan analogi',
      'Belajar dalam suasana yang tenang dan inspiratif'
    ],
    color: 'from-purple-400 to-purple-600',
    emoji: '🔮'
  },
  'INTJ': {
    title: 'Perencana yang Visioner',
    description: 'Anak yang analitis, independen, suka merencanakan, dan punya tujuan jelas. Kamu suka memecahkan masalah kompleks.',
    detailedDescription: 'Kamu adalah anak yang sangat analitis dan strategis. Kamu suka membuat rencana jangka panjang dan bekerja keras untuk mencapainya. Kamu memiliki kemampuan untuk melihat pola dan membuat koneksi yang tidak terlihat orang lain.',
    strengths: ['Sangat analitis', 'Independen', 'Visioner', 'Logis', 'Perencana strategis'],
    challenges: ['Terlalu kritis', 'Sulit bekerja dalam tim', 'Terlalu percaya diri', 'Kurang sabar'],
    professions: ['Ilmuwan', 'Arsitek', 'Insinyur', 'Analisis Sistem', 'Pengacara', 'Dokter', 'Manajer Strategis', 'Peneliti'],
    learning: 'Belajar dengan proyek mandiri, analisis mendalam, dan tantangan intelektual. Berikan waktu untuk berpikir.',
    detailedLearning: 'Kamu adalah learner yang independen dan analitis. Kamu belajar paling baik ketika diberikan kebebasan untuk mengeksplorasi topik secara mendalam dan membuat koneksi kompleks antar konsep.',
    learningRecommendations: [
      'Carilah materi yang menantang intelektual',
      'Buat rencana belajar jangka panjang',
      'Fokus pada pemahaman konsep daripada menghafal',
      'Gunakan analisis SWOT untuk setiap topik',
      'Diskusikan ide dengan orang yang selevel',
      'Buat proyek penelitian mandiri',
      'Gunakan diagram alir dan sistem thinking'
    ],
    color: 'from-indigo-400 to-indigo-600',
    emoji: '🎯'
  },
  'ISTP': {
    title: 'Ahli Praktis yang Terampil',
    description: 'Anak yang suka praktek, logis, fleksibel, dan pandai memecahkan masalah. Kamu suka mencoba hal baru langsung.',
    detailedDescription: 'Kamu adalah anak yang sangat praktis dan suka mencoba hal-hal baru secara langsung. Kamu pandai memecahkan masalah yang terjadi di hadapanmu dan selalu ingin tahu bagaimana sesuatu bekerja. Kamu fleksibel dan mudah beradaptasi.',
    strengths: ['Sangat praktis', 'Pandai memecahkan masalah', 'Fleksibel', 'Terampil secara manual', 'Cepat belajar praktek'],
    challenges: ['Sulit berkomitmen', 'Kurang sabar dengan teori', 'Terlalu impulsif', 'Sulit merencanakan'],
    professions: ['Mekanik', 'Insinyur', 'Pilot', 'Dokter Bedah', 'Atlet', 'Pemadam Kebakaran', 'Teknisi', 'Desainer Produk'],
    learning: 'Belajar dengan praktik langsung, eksperimen, dan proyek tangan. Kurangi teori, tambah praktek.',
    detailedLearning: 'Kamu adalah kinesthetic learner yang belajar paling baik dengan melakukan. Kamu perlu mencoba langsung apa yang kamu pelajari dan melihat cara kerjanya secara praktis.',
    learningRecommendations: [
      'Praktikkan langsung setiap konsep',
      'Bongkar dan pasang kembali objek untuk memahami',
      'Gunakan eksperimen dan demonstrasi',
      'Pelajari dengan cara mencoba-coba',
      'Gunakan alat dan peraga pembelajaran',
      'Ambil kursus praktik atau workshop',
      'Fokus pada aplikasi nyata dari teori'
    ],
    color: 'from-yellow-400 to-orange-500',
    emoji: '🔧'
  },
  'ISFP': {
    title: 'Seniman yang Hangat',
    description: 'Anak yang kreatif, sensitif, menghargai keindahan, dan menghindari konflik. Kamu punya selera yang unik.',
    detailedDescription: 'Kamu adalah anak yang sangat kreatif dan memiliki selera artistik yang tinggi. Kamu sensitif terhadap keindahan dan emosi, baik milikmu maupun orang lain. Kamu menghargai kebebasan dan tidak suka dikendalikan.',
    strengths: ['Sangat kreatif', 'Sensitif', 'Setia', 'Fleksibel', 'Berjiwa seni'],
    challenges: ['Terlalu sensitif', 'Sulit membuat keputusan', 'Menghindari konflik', 'Prokrastinasi'],
    professions: ['Seniman', 'Desainer', 'Penulis', 'Fotografer', 'Musisi', 'Psikolog', 'Guru Seni', 'Terapis Seni'],
    learning: 'Belajar dengan seni, musik, dan proyek kreatif. Berikan kebebasan untuk mengekspresikan diri.',
    detailedLearning: 'Kamu adalah learner yang kreatif dan ekspresif. Kamu belajar paling baik ketika bisa mengekspresikan diri secara artistik dan diberikan kebebasan untuk mengeksplorasi ide-ide kreatif.',
    learningRecommendations: [
      'Gunakan seni dan musik dalam belajar',
      'Buat portofolio kreatif dari hasil belajar',
      'Gunakan warna dan gambar dalam catatan',
      'Tulis puisi atau cerita tentang konsep',
      'Belajar dalam lingkungan yang indah dan nyaman',
      'Gunakan proyek kreatif untuk menunjukkan pemahaman',
      'Berikan waktu untuk refleksi dan ekspresi diri'
    ],
    color: 'from-pink-400 to-rose-500',
    emoji: '🎨'
  },
  'INFP': {
    title: 'Penyembuh yang Idealis',
    description: 'Anak yang idealis, kreatif, setia pada nilai-nilai, dan ingin membantu orang lain. Kamu punya dunia imajinasi yang kaya.',
    detailedDescription: 'Kamu adalah anak yang sangat idealis dan memiliki nilai-nilai yang kuat. Kamu selalu melihat potensi terbaik dalam diri orang lain dan ingin membantu mereka mencapainya. Kamu memiliki imajinasi yang kaya dan dunia batin yang dalam.',
    strengths: ['Sangat idealis', 'Kreatif', 'Setia pada nilai', 'Empati', 'Imajinatif'],
    challenges: ['Terlalu idealis', 'Sulit menerima kenyataan', 'Prokrastinasi', 'Terlalu sensitif'],
    professions: ['Penulis', 'Psikolog', 'Konselor', 'Guru', 'Jurnalis', 'Seniman', 'Pekerja Sosial', 'Filsuf'],
    learning: 'Belajar dengan cerita, proyek kreatif, dan topik yang punya makna mendalam. Berikan waktu refleksi.',
    detailedLearning: 'Kamu adalah learner yang idealis dan kreatif. Kamu belajar paling baik ketika materi memiliki makna mendalam dan sesuai dengan nilai-nilaimu. Kamu perlu waktu untuk refleksi dan pemrosesan internal.',
    learningRecommendations: [
      'Hubungkan pelajaran dengan nilai-nilai pribadi',
      'Gunakan cerita dan narasi dalam belajar',
      'Buat jurnal reflektif tentang apa yang dipelajari',
      'Carilah topik yang memiliki dampak sosial',
      'Gunakan imajinasi untuk memvisualisasikan konsep',
      'Buat proyek kreatif yang ekspresif',
      'Belajar dalam lingkungan yang tenang dan mendukung'
    ],
    color: 'from-teal-400 to-cyan-600',
    emoji: '✨'
  },
  'INTP': {
    title: 'Pemikir yang Logis',
    description: 'Anak yang suka analisis, logis, objektif, dan penasaran dengan segala hal. Kamu suka memahami bagaimana sesuatu bekerja.',
    detailedDescription: 'Kamu adalah anak yang sangat analitis dan selalu ingin tahu "mengapa" dan "bagaimana" sesuatu bekerja. Kamu menikmati pemecahan masalah kompleks dan selalu mencari pemahaman yang mendalam tentang topik yang menarik bagimu.',
    strengths: ['Sangat analitis', 'Logis', 'Objektif', 'Kreatif', 'Pintar'],
    challenges: ['Sulit berkomunikasi', 'Terlalu kritis', 'Prokrastinasi', 'Kurang praktis'],
    professions: ['Ilmuwan', 'Programmer', 'Insinyur', 'Analisis Sistem', 'Filsuf', 'Peneliti', 'Dosen', 'Arsitek'],
    learning: 'Belajar dengan eksperimen, analisis konsep, dan diskusi logis. Berikan kebebasan untuk mengeksplorasi ide.',
    detailedLearning: 'Kamu adalah learner yang konseptual dan teoretis. Kamu belajar paling baik ketika bisa menganalisis sistem dan memahami prinsip-prinsip dasar. Kamu menikmati eksplorasi intelektual dan pemecahan masalah kompleks.',
    learningRecommendations: [
      'Fokus pada pemahaman konsep daripada menghafal',
      'Gunakan diagram sistem dan flowchart',
      'Debatkan ide-ide dengan orang lain',
      'Carilah materi yang menantang secara intelektual',
      'Buat model teoretis dari apa yang dipelajari',
      'Gunakan metode ilmiah dalam eksperimen',
      'Berikan waktu untuk berpikir dan menganalisis'
    ],
    color: 'from-gray-400 to-slate-600',
    emoji: '🧠'
  },
  'ESTP': {
    title: 'Pengusaha yang Energik',
    description: 'Anak yang aktif, enerjik, suka petualangan, dan pandai dalam situasi praktis. Kamu suka mencoba hal baru.',
    detailedDescription: 'Kamu adalah anak yang sangat energik dan suka petualangan. Kamu pandai dalam situasi praktis dan selalu siap untuk mencoba hal baru. Kamu belajar paling baik dengan melakukan dan menikmati tantangan.',
    strengths: ['Sangat energik', 'Praktis', 'Pandai adaptasi', 'Berani', 'Sensitif terhadap lingkungan'],
    challenges: ['Impulsif', 'Sulit berkomitmen', 'Bosan cepat', 'Kurang perencanaan'],
    professions: ['Pengusaha', 'Atlet', 'Pemasar', 'Penjual', 'Pemandu Wisata', 'Polisi', 'Pemadam Kebakaran', 'Insinyur Lapangan'],
    learning: 'Belajar dengan aktivitas fisik, kompetisi, dan praktek langsung. Variasikan metode belajar.',
    detailedLearning: 'Kamu adalah kinesthetic learner yang belajar paling baik melalui pengalaman langsung. Kamu perlu variasi dan stimulasi fisik untuk tetap terlibat dan termotivasi.',
    learningRecommendations: [
      'Gunakan permainan dan kompetisi dalam belajar',
      'Lakukan kegiatan fisik sambil belajar',
      'Praktikkan langsung setiap konsep',
      'Gunakan role playing dan simulasi',
      'Carilah pengalaman belajar di luar kelas',
      'Gunakan timer dan challenge system',
      'Variasikan metode belajar untuk menghindari kebosanan'
    ],
    color: 'from-red-400 to-red-600',
    emoji: '🎪'
  },
  'ESFP': {
    title: 'Penghibur yang Ceria',
    description: 'Anak yang ceria, ramah, suka menjadi pusat perhatian, dan peduli dengan orang lain. Kamu punya energi yang positif.',
    detailedDescription: 'Kamu adalah anak yang sangat ceria dan energik. Kamu suka menjadi pusat perhatian dan pandai membuat orang lain bahagia. Kamu sangat peduli dengan perasaan orang lain dan selalu siap membantu.',
    strengths: ['Sangat ceria', 'Sosial', 'Empati', 'Praktis', 'Pandai bergaul'],
    challenges: ['Sulit fokus', 'Impulsif', 'Menghindari konflik', 'Sulit berkomitmen'],
    professions: ['Aktor', 'Seniman', 'Guru', 'Pemasar', 'Perawat', 'Pekerja Sosial', 'Pemandu Acara', 'Desainer'],
    learning: 'Belajar dengan diskusi kelompok, permainan, dan aktivitas sosial. Buat belajar menjadi menyenangkan.',
    detailedLearning: 'Kamu adalah sosial learner yang belajar paling baik dalam lingkungan interaktif dan menyenangkan. Kamu perlu interaksi sosial dan variasi untuk tetap termotivasi.',
    learningRecommendations: [
      'Belajar dalam kelompok yang interaktif',
      'Gunakan permainan dan aktivitas menyenangkan',
      'Diskusikan materi dengan teman-teman',
      'Gunakan role playing dan drama',
      'Buat presentasi yang menarik',
      'Carilah guru yang humoris dan energik',
      'Gunakan reward system untuk motivasi'
    ],
    color: 'from-orange-400 to-amber-500',
    emoji: '🎭'
  },
  'ENFP': {
    title: 'Pemimpin Karismatik',
    description: 'Anak yang antusias, kreatif, suka berteman, dan penuh ide. Kamu bisa menginspirasi orang lain.',
    detailedDescription: 'Kamu adalah anak yang sangat antusias dan penuh energi. Kamu suka berteman dengan orang baru dan selalu punya ide-ide kreatif. Kamu bisa menginspirasi orang lain dengan karisma dan optimismemu.',
    strengths: ['Sangat kreatif', 'Antusias', 'Sosial', 'Optimis', 'Inspiratif'],
    challenges: ['Sulit fokus', 'Impulsif', 'Terlalu idealis', 'Prokrastinasi'],
    professions: ['Guru', 'Penulis', 'Pemasar', 'Psikolog', 'Pengusaha', 'Jurnalis', 'Seniman', 'Pekerja Sosial'],
    learning: 'Belajar dengan diskusi, proyek kreatif, dan kerja kelompok. Sambungkan pelajaran dengan kehidupan nyata.',
    detailedLearning: 'Kamu adalah kreatif dan sosial learner yang belajar paling baik ketika bisa menghubungkan ide-ide dan bekerja dengan orang lain. Kamu perlu variasi dan makna dalam pembelajaran.',
    learningRecommendations: [
      'Gunakan brainstorming dan mind mapping',
      'Buat proyek kreatif dan inovatif',
      'Diskusikan ide dengan orang lain',
      'Hubungkan pelajaran dengan kehidupan nyata',
      'Gunakan cerita dan narasi dalam belajar',
      'Buat jurnal ide kreatif',
      'Belajar dalam kelompok yang supportif'
    ],
    color: 'from-yellow-400 to-yellow-600',
    emoji: '🌟'
  },
  'ENTP': {
    title: 'Debatir yang Cerdas',
    description: 'Anak yang cerdas, suka debat, kreatif, dan pandai melihat kemungkinan baru. Kamu suka menantang status quo.',
    detailedDescription: 'Kamu adalah anak yang sangat cerdas dan suka menantang ide-ide yang sudah ada. Kamu pandai melihat berbagai kemungkinan dan suka berdebat untuk membuktikan pemikiranmu. Kamu selalu mencari cara baru untuk melakukan sesuatu.',
    strengths: ['Sangat cerdas', 'Kreatif', 'Pandai debat', 'Inovatif', 'Fleksibel'],
    challenges: ['Suka menantang', 'Sulit fokus', 'Terlalu kritis', 'Prokrastinasi'],
    professions: ['Pengacara', 'Ilmuwan', 'Pengusaha', 'Konsultan', 'Jurnalis', 'Dosen', 'Analisis Sistem', 'Peneliti'],
    learning: 'Belajar dengan debat, proyek inovatif, dan pemecahan masalah kreatif. Berikan tantangan intelektual.',
    detailedLearning: 'Kamu adalah debater dan inovator yang belajar paling baik ketika bisa menantang ide-ide dan mengeksplorasi kemungkinan baru. Kamu perlu stimulasi intelektual dan kebebasan untuk berpikir kritis.',
    learningRecommendations: [
      'Gunakan debat dan diskusi kritis',
      'Carilah materi yang menantang status quo',
      'Buat proyek inovatif dan kreatif',
      'Challenge ide-ide yang sudah ada',
      'Gunakan metode problem solving',
      'Diskusikan dengan orang yang pandai',
      'Carilah mentor yang bisa menantangmu'
    ],
    color: 'from-cyan-400 to-blue-500',
    emoji: '🎯'
  },
  'ESTJ': {
    title: 'Pengatur yang Terorganisir',
    description: 'Anak yang terorganisir, bertanggung jawab, suka aturan, dan pandai memimpin. Kamu bisa mengatur orang lain.',
    detailedDescription: 'Kamu adalah anak yang sangat terorganisir dan suka mengatur segala sesuatu. Kamu bertanggung jawab dan bisa diandalkan untuk menyelesaikan tugas. Kamu pandai memimpin dan mengatur orang lain untuk mencapai tujuan.',
    strengths: ['Sangat terorganisir', 'Pemimpin', 'Bertanggung jawab', 'Praktis', 'Dapat diandalkan'],
    challenges: ['Terlalu kaku', 'Sulit menerima perubahan', 'Terlalu kritis', 'Kurang fleksibel'],
    professions: ['Manajer', 'Pengacara', 'Militer', 'Guru', 'Akuntan', 'Dokter', 'Insinyur', 'Pengusaha'],
    learning: 'Belajar dengan struktur yang jelas, tujuan spesifik, dan penghargaan atas pencapaian. Berikan tanggung jawab.',
    detailedLearning: 'Kamu adalah structured learner yang belajar paling baik dengan sistem yang jelas dan terorganisir. Kamu perlu tujuan spesifik dan feedback yang jelas untuk tetap termotivasi.',
    learningRecommendations: [
      'Buat rencana belajar yang terstruktur',
      'Gunakan sistem reward dan penghargaan',
      'Tetapkan tujuan spesifik dan terukur',
      'Gunakan metode belajar yang sistematis',
      'Ambil peran kepemimpinan dalam kelompok',
      'Gunakan feedback dan evaluasi reguler',
      'Fokus pada hasil dan pencapaian'
    ],
    color: 'from-emerald-400 to-green-600',
    emoji: '📊'
  },
  'ESFJ': {
    title: 'Pendukung yang Sosial',
    description: 'Anak yang hangat, suka membantu, kooperatif, dan peduli dengan perasaan orang lain. Kamu suka membuat orang bahagia.',
    detailedDescription: 'Kamu adalah anak yang sangat hangat dan suka membantu orang lain. Kamu peduli dengan perasaan orang lain dan selalu berusaha membuat orang lain bahagia. Kamu pandai bekerja dalam tim dan sangat kooperatif.',
    strengths: ['Sangat sosial', 'Kooperatif', 'Empati', 'Organisir', 'Setia'],
    challenges: ['Terlalu fokus pada orang lain', 'Sulit membuat keputusan', 'Menghindari konflik', 'Sensitif'],
    professions: ['Perawat', 'Guru', 'Pekerja Sosial', 'Psikolog', 'Manajer SDM', 'Pemasar', 'Penjual', 'Konsultan'],
    learning: 'Belajar dengan kerja kelompok, proyek sosial, dan feedback positif. Fokus pada bagaimana ilmu membantu orang.',
    detailedLearning: 'Kamu adalah sosial learner yang belajar paling baik dalam lingkungan harmonis dan kolaboratif. Kamu perlu interaksi positif dan tujuan sosial untuk tetap termotivasi.',
    learningRecommendations: [
      'Belajar dalam kelompok yang harmonis',
      'Fokus pada dampak sosial dari pembelajaran',
      'Gunakan metode belajar kolaboratif',
      'Carilah guru yang suportif dan hangat',
      'Buat proyek yang membantu orang lain',
      'Gunakan feedback positif dan reinforcement',
      'Jadwalkan diskusi dan sharing session'
    ],
    color: 'from-rose-400 to-pink-600',
    emoji: '💝'
  },
  'ENFJ': {
    title: 'Pembimbing Karismatik',
    description: 'Anak yang karismatik, peduli, pandai memotivasi, dan suka membantu orang lain berkembang. Kamu pemimpin alami.',
    detailedDescription: 'Kamu adalah anak yang sangat karismatik dan pandai memotivasi orang lain. Kamu peduli dengan perkembangan orang lain dan selalu siap membantu mereka menjadi versi terbaik diri mereka. Kamu adalah pemimpin alami yang bisa menginspirasi orang lain.',
    strengths: ['Sangat karismatik', 'Pemimpin', 'Empati', 'Motivator', 'Inspiratif'],
    challenges: ['Terlalu fokus pada orang lain', 'Sulit berkata tidak', 'Idealis', 'Sensitif'],
    professions: ['Guru', 'Psikolog', 'Konsultan', 'Manajer', 'Pengusaha', 'Pekerja Sosial', 'Politisi', 'Pembicara Publik'],
    learning: 'Belajar dengan diskusi kelompok, proyek kepemimpinan, dan topik yang membantu orang lain. Berikan kesempatan memimpin.',
    detailedLearning: 'Kamu adalah pemimpin dan mentor yang belajar paling baik ketika bisa membantu orang lain dan mengembangkan potensi mereka. Kamu perlu tujuan sosial dan kesempatan untuk memimpin.',
    learningRecommendations: [
      'Ambil peran kepemimpinan dalam proyek',
      'Bantu teman yang kesulitan belajar',
      'Fokus pada topik yang memiliki dampak sosial',
      'Gunakan metode belajar kolaboratif',
      'Buat sesi mentoring dan coaching',
      'Carilah mentor yang bisa menginspirasi',
      'Gunakan public speaking dan presentasi'
    ],
    color: 'from-purple-400 to-indigo-600',
    emoji: '👑'
  },
  'ENTJ': {
    title: 'Komandan yang Visioner',
    description: 'Anak yang pemimpin, strategis, percaya diri, dan punya visi jelas. Kamu bisa mengorganisir orang untuk mencapai tujuan.',
    detailedDescription: 'Kamu adalah anak yang sangat percaya diri dan punya visi yang jelas. Kamu pandai mengorganisir orang dan sumber daya untuk mencapai tujuan. Kamu adalah pemimpin alami yang bisa menginspirasi dan memotivasi orang lain.',
    strengths: ['Sangat percaya diri', 'Pemimpin', 'Strategis', 'Visioner', 'Kompetitif'],
    challenges: ['Terlalu dominan', 'Sulit menerima kritik', 'Impulsif', 'Kurang sabar'],
    professions: ['CEO', 'Pengacara', 'Konsultan', 'Manajer', 'Pengusaha', 'Politisi', 'Dokter', 'Insinyur'],
    learning: 'Belajar dengan proyek kepemimpinan, tantangan strategis, dan kesempatan mengorganisir. Berikan tanggung jawab besar.',
    detailedLearning: 'Kamu adalah pemimpin dan strategis yang belajar paling baik ketika diberikan tantangan besar dan tanggung jawab. Kamu perlu tujuan yang menantang dan kesempatan untuk mengorganisir.',
    learningRecommendations: [
      'Ambil peran kepemimpinan dalam proyek besar',
      'Fokus pada strategi dan perencanaan jangka panjang',
      'Carilah tantangan yang menantang',
      'Gunakan metode problem solving kompleks',
      'Buat rencana dan eksekusi proyek',
      'Carilah mentor yang sukses',
      'Fokus pada hasil dan pencapaian'
    ],
    color: 'from-red-500 to-orange-600',
    emoji: '🏆'
  }
}

type PageType = 'home' | 'learn' | 'dimension-detail' | 'mbti-test' | 'vak-test' | 'results'

interface DimensionDetail {
  title: string
  description: string
  examples: string[]
  emoji: string
}

const dimensionDetails: Record<string, DimensionDetail> = {
  'EI': {
    title: 'Extraversion (E) vs Introversion (I)',
    description: 'Bagaimana kamu mendapatkan energi dan berinteraksi dengan dunia!',
    examples: [
      'E - Anak Extraversion: Suka berbicara, mudah berteman, suka keramaian',
      'I - Anak Introversion: Lebih nyaman sendiri, suka berpikir, pendiam'
    ],
    emoji: '🎭'
  },
  'SN': {
    title: 'Sensing (S) vs Intuition (N)',
    description: 'Bagaimana kamu melihat dunia dan mengambil informasi!',
    examples: [
      'S - Anak Sensing: Suka fakta nyata, praktis, detail-oriented',
      'N - Anak Intuition: Suka imajinasi, konsep besar, kreatif'
    ],
    emoji: '🔍'
  },
  'TF': {
    title: 'Thinking (T) vs Feeling (F)',
    description: 'Bagaimana kamu mengambil keputusan dan menilai sesuatu!',
    examples: [
      'T - Anak Thinking: Logis, objektif, suka analisis',
      'F - Anak Feeling: Perhatian pada perasaan, empati, nilai-nilai'
    ],
    emoji: '💭'
  },
  'JP': {
    title: 'Judging (J) vs Perceiving (P)',
    description: 'Bagaimana kamu mengatur hidup dan menghadapi dunia!',
    examples: [
      'J - Anak Judging: Terorganisir, suka rencana, teratur',
      'P - Anak Perceiving: Fleksibel, spontan, terbuka'
    ],
    emoji: '📋'
  }
}

export default function Home() {
  const [currentPage, setCurrentPage] = useState<PageType>('home')
  const [selectedDimension, setSelectedDimension] = useState<string>('')
  const [studentName, setStudentName] = useState('')
  const [mbtiScores, setMbtiScores] = useState({ E: 0, I: 0, S: 0, N: 0, T: 0, F: 0, J: 0, P: 0 })
  const [vakScores, setVakScores] = useState({ V: 0, A: 0, K: 0 })
  const [currentMbtiQuestion, setCurrentMbtiQuestion] = useState(0)
  const [currentVakQuestion, setCurrentVakQuestion] = useState(0)
  const [mbtiAnswers, setMbtiAnswers] = useState<Record<number, string>>({})
  const [vakAnswers, setVakAnswers] = useState<Record<number, boolean>>({})

  const handleMbtiAnswer = (answer: string) => {
    const question = mbtiQuestions[currentMbtiQuestion]
    const newAnswers = { ...mbtiAnswers, [question.id]: answer }
    setMbtiAnswers(newAnswers)

    // Update scores
    const newScores = { ...mbtiScores }
    if (answer === 'A') {
      if (question.dimension === 'EI') newScores.E++
      else if (question.dimension === 'SN') newScores.S++
      else if (question.dimension === 'TF') newScores.T++
      else if (question.dimension === 'JP') newScores.J++
    } else {
      if (question.dimension === 'EI') newScores.I++
      else if (question.dimension === 'SN') newScores.N++
      else if (question.dimension === 'TF') newScores.F++
      else if (question.dimension === 'JP') newScores.P++
    }
    setMbtiScores(newScores)

    if (currentMbtiQuestion < mbtiQuestions.length - 1) {
      setCurrentMbtiQuestion(currentMbtiQuestion + 1)
    } else {
      setCurrentPage('vak-test')
    }
  }

  const handleVakAnswer = (answer: boolean) => {
    const question = vakQuestions[currentVakQuestion]
    const newAnswers = { ...vakAnswers, [question.id]: answer }
    setVakAnswers(newAnswers)

    // Update scores
    const newScores = { ...vakScores }
    if (answer) {
      newScores[question.style as 'V' | 'A' | 'K']++
    }
    setVakScores(newScores)

    if (currentVakQuestion < vakQuestions.length - 1) {
      setCurrentVakQuestion(currentVakQuestion + 1)
    } else {
      setCurrentPage('results')
    }
  }

  const calculateMbtiType = () => {
    const type = 
      (mbtiScores.E >= mbtiScores.I ? 'E' : 'I') +
      (mbtiScores.S >= mbtiScores.N ? 'S' : 'N') +
      (mbtiScores.T >= mbtiScores.F ? 'T' : 'F') +
      (mbtiScores.J >= mbtiScores.P ? 'J' : 'P')
    return type
  }

  const calculateVakStyle = () => {
    const max = Math.max(vakScores.V, vakScores.A, vakScores.K)
    if (vakScores.V === max) return 'Visual'
    if (vakScores.A === max) return 'Auditori'
    return 'Kinestetik'
  }

  const getVakRecommendation = (style: string) => {
    switch (style) {
      case 'Visual':
        return {
          title: 'Pembelajar Visual',
          description: 'Kamu belajar paling baik dengan melihat dan mengamati. Kamu lebih mudah mengingat informasi yang bisa kamu lihat seperti gambar, diagram, dan tulisan.',
          detailedDescription: 'Kamu adalah tipe pembelajar visual yang memproses informasi paling baik melalui penglihatan. Kamu lebih mudah memahami konsep ketika bisa melihatnya dalam bentuk visual seperti diagram, grafik, atau demonstrasi.',
          characteristics: [
            'Lebih mudah mengingat wajah daripada nama',
            'Suka membuat catatan yang rapi dan berwarna',
            'Lebih suka membaca daripada mendengarkan',
            'Mudah terganggu oleh lingkungan yang berantakan',
            'Suka menggunakan highlighter dan warna',
            'Lebih suka belajar dengan video dan gambar'
          ],
          recommendations: [
            'Gunakan warna-warna dalam catatan belajar',
            'Buat mind map dan diagram alir',
            'Gunakan flashcard dengan gambar',
            'Tonton video edukasi',
            'Buat grafik dan tabel untuk informasi',
            'Gunakan highlighter untuk menandai penting',
            'Belajar di tempat yang rapi dan teratur',
            'Gunakan teknik visualisasi untuk mengingat'
          ]
        }
      case 'Auditori':
        return {
          title: 'Pembelajar Auditori',
          description: 'Kamu belajar paling baik dengan mendengarkan dan berbicara. Kamu lebih mudah mengingat informasi yang kamu dengar.',
          detailedDescription: 'Kamu adalah tipe pembelajar auditori yang memproses informasi paling baik melalui pendengaran. Kamu lebih mudah memahami konsep ketika bisa mendengarkannya dijelaskan atau membacanya dengan suara keras.',
          characteristics: [
            'Lebih mudah mengingat nama daripada wajah',
            'Suka berdiskusi dan bertanya',
            'Lebih suka mendengarkan penjelasan daripada membaca',
            'Suka membaca dengan suara keras',
            'Mudah terganggu oleh suara bising',
            'Suka musik dan belajar dengan musik'
          ],
          recommendations: [
            'Bacalah pelajaran dengan suara keras',
            'Ikuti diskusi kelompok dan tanya jawab',
            'Gunakan audio book atau rekaman penjelasan',
            'Buat jingle atau lagu untuk mengingat',
            'Ulangi materi dengan suara keras',
            'Gunakan teknik mnemonik dengan suara',
            'Belajar dengan teman dan diskusikan materi',
            'Gunakan metode pengulangan verbal'
          ]
        }
      case 'Kinestetik':
        return {
          title: 'Pembelajar Kinestetik',
          description: 'Kamu belajar paling baik dengan melakukan dan bergerak. Kamu lebih mudah mengingat informasi ketika bisa langsung mempraktikkannya.',
          detailedDescription: 'Kamu adalah tipe pembelajar kinestetik yang memproses informasi paling baik melalui pengalaman fisik dan gerakan. Kamu lebih mudah memahami konsep ketika bisa langsung mencobanya dan bergerak.',
          characteristics: [
            'Suka bergerak saat belajar',
            'Lebih mudah mengingat dengan praktek langsung',
            'Suka mencoba-coba dan eksperimen',
            'Mudah bosan jika duduk terlalu lama',
            'Suka proyek tangan dan aktivitas fisik',
            'Belajar paling baik dengan melakukan'
          ],
          recommendations: [
            'Lakukan gerakan saat belajar konsep',
            'Gunakan alat peraga dan manipulatif',
            'Praktikkan langsung apa yang dipelajari',
            'Ambil jalan-jalan singkat saat belajar',
            'Gunakan role playing dan simulasi',
            'Buat proyek tangan untuk demonstrasi',
            'Belajar sambil bermain atau berolahraga',
            'Gunakan eksperimen dan praktikum'
          ]
        }
      default:
        return {
          title: '',
          description: '',
          detailedDescription: '',
          characteristics: [],
          recommendations: []
        }
    }
  }

  const resultsRef = useRef<HTMLDivElement>(null)

  const exportToPDF = async () => {
    if (resultsRef.current) {
      try {
        const canvas = await html2canvas(resultsRef.current, {
          scale: 2,
          useCORS: true,
          allowTaint: true,
          backgroundColor: '#ffffff'
        })
        
        const imgData = canvas.toDataURL('image/png')
        const pdf = new jsPDF('p', 'mm', 'a4')
        
        const pdfWidth = pdf.internal.pageSize.getWidth()
        const pdfHeight = pdf.internal.pageSize.getHeight()
        const imgWidth = canvas.width
        const imgHeight = canvas.height
        const ratio = Math.min(pdfWidth / imgWidth, pdfHeight / imgHeight) * 200
        const imgX = (pdfWidth - imgWidth * ratio / 200) / 2
        const imgY = 10
        
        pdf.addImage(imgData, 'PNG', imgX, imgY, imgWidth * ratio / 200, imgHeight * ratio / 200)
        pdf.save(`Hasil-Tes-Kepribadian-${studentName}.pdf`)
      } catch (error) {
        console.error('Error generating PDF:', error)
      }
    }
  }

  const exportToJPG = async () => {
    if (resultsRef.current) {
      try {
        const canvas = await html2canvas(resultsRef.current, {
          scale: 2,
          useCORS: true,
          allowTaint: true,
          backgroundColor: '#ffffff'
        })
        
        const link = document.createElement('a')
        link.download = `Hasil-Tes-Kepribadian-${studentName}.jpg`
        link.href = canvas.toDataURL('image/jpeg', 0.9)
        link.click()
      } catch (error) {
        console.error('Error generating JPG:', error)
      }
    }
  }

  const resetTest = () => {
    setStudentName('')
    setMbtiScores({ E: 0, I: 0, S: 0, N: 0, T: 0, F: 0, J: 0, P: 0 })
    setVakScores({ V: 0, A: 0, K: 0 })
    setCurrentMbtiQuestion(0)
    setCurrentVakQuestion(0)
    setMbtiAnswers({})
    setVakAnswers({})
    setCurrentPage('home')
  }

  const renderHomePage = () => (
    <div className="min-h-screen bg-gradient-to-br from-pink-100 via-purple-100 to-blue-100 p-4">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-8">
          <div className="text-6xl mb-4">🌟</div>
          <h1 className="text-4xl md:text-6xl font-bold text-purple-800 mb-4">
            Tes Kepribadian & Gaya Belajar Anak
          </h1>
          <p className="text-xl md:text-2xl text-purple-600 mb-2">
            Kenali dirimu, temukan cara belajarmu, dan jadilah versi terbaikmu!
          </p>
          <p className="text-lg text-purple-500">
            Dibuat untuk memudahkan guru dan siswa memahami kepribadian serta gaya belajar dengan cara menyenangkan.
          </p>
        </div>

        <div className="flex flex-col md:flex-row gap-6 justify-center mb-8">
          <Button 
            onClick={() => setCurrentPage('mbti-test')}
            className="bg-gradient-to-r from-pink-500 to-purple-500 hover:from-pink-600 hover:to-purple-600 text-white text-xl px-8 py-6 rounded-2xl transform hover:scale-105 transition-all duration-200"
          >
            🎯 Mulai Tes Sekarang
          </Button>
          <Button 
            onClick={() => setCurrentPage('learn')}
            className="bg-gradient-to-r from-blue-500 to-green-500 hover:from-blue-600 hover:to-green-600 text-white text-xl px-8 py-6 rounded-2xl transform hover:scale-105 transition-all duration-200"
          >
            📚 Pelajari Tipe Kepribadian
          </Button>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          <Card className="bg-white/80 backdrop-blur-sm border-2 border-purple-200">
            <CardHeader>
              <CardTitle className="text-2xl text-purple-800 flex items-center gap-2">
                🎭 MBTI untuk Anak
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-700">
                Temukan tipe kepribadian unikmu! Apakah kamu seorang pemimpin, seniman, 
                pemikir, atau pendukung? Setiap anak itu spesial dengan caranya sendiri.
              </p>
            </CardContent>
          </Card>

          <Card className="bg-white/80 backdrop-blur-sm border-2 border-blue-200">
            <CardHeader>
              <CardTitle className="text-2xl text-blue-800 flex items-center gap-2">
                🧠 Gaya Belajar VAK
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-700">
                Pelajari cara terbaik untukmu belajar! Apakah kamu lebih suka melihat, 
                mendengarkan, atau melakukan langsung?
              </p>
            </CardContent>
          </Card>
        </div>
      </div>

      <footer className="text-center mt-12 pb-8">
        <p className="text-purple-700 font-medium">
          Website ini dibuat oleh <strong>Teguh Gunawan Bahtiar</strong>
        </p>
        <p className="text-purple-600">
          Telegram: <a href="https://t.me/abughaisani" target="_blank" rel="noopener noreferrer" className="hover:underline">@abughaisani (t.me/abughaisani)</a>
        </p>
      </footer>
    </div>
  )

  const renderLearnPage = () => (
    <div className="min-h-screen bg-gradient-to-br from-blue-100 via-purple-100 to-pink-100 p-4">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-4xl md:text-5xl font-bold text-purple-800 mb-4">
            📚 Pelajari Tipe Kepribadian
          </h1>
          <p className="text-xl text-purple-600">
            Kenali 4 dimensi kepribadian yang membuatmu unik!
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-6 mb-8">
          <Button 
            onClick={() => { setSelectedDimension('EI'); setCurrentPage('dimension-detail') }}
            className="bg-gradient-to-r from-red-400 to-pink-400 hover:from-red-500 hover:to-pink-500 text-white text-xl p-8 rounded-2xl h-auto"
          >
            <div className="text-center">
              <div className="text-4xl mb-2">🎭</div>
              <div className="font-bold">Extraversion (E)</div>
              <div className="text-lg">vs</div>
              <div className="font-bold">Introversion (I)</div>
              <div className="text-sm mt-2">Energi & Interaksi</div>
            </div>
          </Button>

          <Button 
            onClick={() => { setSelectedDimension('SN'); setCurrentPage('dimension-detail') }}
            className="bg-gradient-to-r from-blue-400 to-cyan-400 hover:from-blue-500 hover:to-cyan-500 text-white text-xl p-8 rounded-2xl h-auto"
          >
            <div className="text-center">
              <div className="text-4xl mb-2">🔍</div>
              <div className="font-bold">Sensing (S)</div>
              <div className="text-lg">vs</div>
              <div className="font-bold">Intuition (N)</div>
              <div className="text-sm mt-2">Cara Memandang Dunia</div>
            </div>
          </Button>

          <Button 
            onClick={() => { setSelectedDimension('TF'); setCurrentPage('dimension-detail') }}
            className="bg-gradient-to-r from-green-400 to-emerald-400 hover:from-green-500 hover:to-emerald-500 text-white text-xl p-8 rounded-2xl h-auto"
          >
            <div className="text-center">
              <div className="text-4xl mb-2">💭</div>
              <div className="font-bold">Thinking (T)</div>
              <div className="text-lg">vs</div>
              <div className="font-bold">Feeling (F)</div>
              <div className="text-sm mt-2">Pengambilan Keputusan</div>
            </div>
          </Button>

          <Button 
            onClick={() => { setSelectedDimension('JP'); setCurrentPage('dimension-detail') }}
            className="bg-gradient-to-r from-purple-400 to-indigo-400 hover:from-purple-500 hover:to-indigo-500 text-white text-xl p-8 rounded-2xl h-auto"
          >
            <div className="text-center">
              <div className="text-4xl mb-2">📋</div>
              <div className="font-bold">Judging (J)</div>
              <div className="text-lg">vs</div>
              <div className="font-bold">Perceiving (P)</div>
              <div className="text-sm mt-2">Gaya Hidup</div>
            </div>
          </Button>
        </div>

        <div className="text-center">
          <Button 
            onClick={() => setCurrentPage('home')}
            className="bg-gray-500 hover:bg-gray-600 text-white text-lg px-6 py-3 rounded-xl"
          >
            🏠 Kembali ke Menu Utama
          </Button>
        </div>
      </div>

      <footer className="text-center mt-12 pb-8">
        <p className="text-purple-700 font-medium">
          Website ini dibuat oleh <strong>Teguh Gunawan Bahtiar</strong>
        </p>
        <p className="text-purple-600">
          Telegram: <a href="https://t.me/abughaisani" target="_blank" rel="noopener noreferrer" className="hover:underline">@abughaisani (t.me/abughaisani)</a>
        </p>
      </footer>
    </div>
  )

  const renderDimensionDetailPage = () => {
    const detail = dimensionDetails[selectedDimension]
    
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-100 via-pink-100 to-blue-100 p-4">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-8">
            <div className="text-6xl mb-4">{detail.emoji}</div>
            <h1 className="text-3xl md:text-4xl font-bold text-purple-800 mb-4">
              {detail.title}
            </h1>
            <p className="text-xl text-purple-600 mb-8">
              {detail.description}
            </p>
          </div>

          <div className="bg-white/80 backdrop-blur-sm rounded-2xl p-8 border-2 border-purple-200">
            <h2 className="text-2xl font-bold text-purple-800 mb-6">Contoh Perilaku Anak:</h2>
            <div className="space-y-4">
              {detail.examples.map((example, index) => (
                <div key={index} className="bg-gradient-to-r from-purple-50 to-pink-50 p-4 rounded-xl">
                  <p className="text-lg text-gray-800">{example}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="text-center mt-8">
            <Button 
              onClick={() => setCurrentPage('learn')}
              className="bg-purple-500 hover:bg-purple-600 text-white text-lg px-6 py-3 rounded-xl mr-4"
            >
              ← Kembali ke Pembelajaran
            </Button>
            <Button 
              onClick={() => setCurrentPage('home')}
              className="bg-gray-500 hover:bg-gray-600 text-white text-lg px-6 py-3 rounded-xl"
            >
              🏠 Menu Utama
            </Button>
          </div>
        </div>

        <footer className="text-center mt-12 pb-8">
          <p className="text-purple-700 font-medium">
            Website ini dibuat oleh <strong>Teguh Gunawan Bahtiar</strong>
          </p>
          <p className="text-purple-600">
            Telegram: <a href="https://t.me/abughaisani" target="_blank" rel="noopener noreferrer" className="hover:underline">@abughaisani (t.me/abughaisani)</a>
          </p>
        </footer>
      </div>
    )
  }

  const renderMbtiTestPage = () => {
    if (currentMbtiQuestion === 0 && Object.keys(mbtiAnswers).length === 0) {
      return (
        <div className="min-h-screen bg-gradient-to-br from-pink-100 via-purple-100 to-blue-100 p-4">
          <div className="max-w-2xl mx-auto">
            <div className="text-center mb-8">
              <h1 className="text-3xl md:text-4xl font-bold text-purple-800 mb-4">
                🎯 Tes Kepribadian MBTI
              </h1>
              <p className="text-xl text-purple-600">
                Mari temukan tipe kepribadian unikmu!
              </p>
            </div>

            <Card className="bg-white/80 backdrop-blur-sm border-2 border-purple-200">
              <CardHeader>
                <CardTitle className="text-2xl text-purple-800">Data Diri</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="name" className="text-lg font-medium text-gray-700">
                    Nama Lengkap Kamu:
                  </Label>
                  <Input
                    id="name"
                    type="text"
                    value={studentName}
                    onChange={(e) => setStudentName(e.target.value)}
                    placeholder="Masukkan nama kamu..."
                    className="text-lg p-4 mt-2"
                  />
                </div>
                <div className="bg-purple-50 p-4 rounded-xl">
                  <p className="text-gray-700">
                    📝 <strong>Petunjuk:</strong> Tes ini memiliki 40 pertanyaan. 
                    Pilih jawaban yang paling sesuai dengan dirimu. Tidak ada jawaban benar atau salah!
                  </p>
                </div>
                <Button 
                  onClick={() => setCurrentMbtiQuestion(1)}
                  disabled={!studentName.trim()}
                  className="w-full bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white text-lg py-4 rounded-xl"
                >
                  Mulai Tes
                </Button>
              </CardContent>
            </Card>

            <div className="text-center mt-8">
              <Button 
                onClick={() => { setCurrentPage('home'); setCurrentMbtiQuestion(0) }}
                className="bg-gray-500 hover:bg-gray-600 text-white text-lg px-6 py-3 rounded-xl"
              >
                ← Kembali
              </Button>
            </div>
          </div>

          <footer className="text-center mt-12 pb-8">
            <p className="text-purple-700 font-medium">
              Website ini dibuat oleh <strong>Teguh Gunawan Bahtiar</strong>
            </p>
            <p className="text-purple-600">
              Telegram: <a href="https://t.me/abughaisani" target="_blank" rel="noopener noreferrer" className="hover:underline">@abughaisani (t.me/abughaisani)</a>
            </p>
          </footer>
        </div>
      )
    }

    const question = mbtiQuestions[currentMbtiQuestion]
    const progress = ((currentMbtiQuestion + 1) / mbtiQuestions.length) * 100

    return (
      <div className="min-h-screen bg-gradient-to-br from-pink-100 via-purple-100 to-blue-100 p-4">
        <div className="max-w-4xl mx-auto">
          <div className="mb-8">
            <div className="flex justify-between items-center mb-4">
              <h1 className="text-2xl md:text-3xl font-bold text-purple-800">
                🎯 Tes Kepribadian MBTI
              </h1>
              <span className="text-lg font-medium text-purple-600">
                {currentMbtiQuestion + 1} / {mbtiQuestions.length}
              </span>
            </div>
            <Progress value={progress} className="h-3" />
          </div>

          <Card className="bg-white/80 backdrop-blur-sm border-2 border-purple-200">
            <CardHeader>
              <CardTitle className="text-xl text-purple-800">
                Pertanyaan {currentMbtiQuestion + 1}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-lg text-gray-800 mb-8">
                {question.text}
              </p>
              
              <div className="space-y-4">
                <Button 
                  onClick={() => handleMbtiAnswer('A')}
                  className="w-full bg-gradient-to-r from-blue-400 to-blue-500 hover:from-blue-500 hover:to-blue-600 text-white text-lg p-6 rounded-xl text-left h-auto"
                >
                  <div className="flex items-center">
                    <span className="text-2xl mr-4">A</span>
                    <span>{question.optionA}</span>
                  </div>
                </Button>
                
                <Button 
                  onClick={() => handleMbtiAnswer('B')}
                  className="w-full bg-gradient-to-r from-green-400 to-green-500 hover:from-green-500 hover:to-green-600 text-white text-lg p-6 rounded-xl text-left h-auto"
                >
                  <div className="flex items-center">
                    <span className="text-2xl mr-4">B</span>
                    <span>{question.optionB}</span>
                  </div>
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        <footer className="text-center mt-12 pb-8">
          <p className="text-purple-700 font-medium">
            Website ini dibuat oleh <strong>Teguh Gunawan Bahtiar</strong>
          </p>
          <p className="text-purple-600">
            Telegram: <a href="https://t.me/abughaisani" target="_blank" rel="noopener noreferrer" className="hover:underline">@abughaisani (t.me/abughaisani)</a>
          </p>
        </footer>
      </div>
    )
  }

  const renderVakTestPage = () => {
    if (currentVakQuestion === 0 && Object.keys(vakAnswers).length === 0) {
      return (
        <div className="min-h-screen bg-gradient-to-br from-blue-100 via-purple-100 to-pink-100 p-4">
          <div className="max-w-2xl mx-auto">
            <div className="text-center mb-8">
              <h1 className="text-3xl md:text-4xl font-bold text-blue-800 mb-4">
                🧠 Tes Gaya Belajar VAK
              </h1>
              <p className="text-xl text-blue-600">
                Temukan cara belajar terbaik untukmu!
              </p>
            </div>

            <Card className="bg-white/80 backdrop-blur-sm border-2 border-blue-200">
              <CardHeader>
                <CardTitle className="text-2xl text-blue-800">Gaya Belajar Quantum Teaching</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="bg-blue-50 p-4 rounded-xl">
                  <p className="text-gray-700 mb-4">
                    📝 <strong>Petunjuk:</strong> Tes ini memiliki 30 pertanyaan tentang gaya belajarmu. 
                    Jawab "Ya" jika pernyataan tersebut sesuai dengan dirimu.
                  </p>
                  <div className="grid md:grid-cols-3 gap-4 mt-6">
                    <div className="bg-red-100 p-4 rounded-xl text-center">
                      <div className="text-3xl mb-2">👁️</div>
                      <h3 className="font-bold text-red-800">Visual</h3>
                      <p className="text-sm text-red-700">Belajar dengan melihat</p>
                    </div>
                    <div className="bg-green-100 p-4 rounded-xl text-center">
                      <div className="text-3xl mb-2">👂</div>
                      <h3 className="font-bold text-green-800">Auditori</h3>
                      <p className="text-sm text-green-700">Belajar dengan mendengar</p>
                    </div>
                    <div className="bg-blue-100 p-4 rounded-xl text-center">
                      <div className="text-3xl mb-2">✋</div>
                      <h3 className="font-bold text-blue-800">Kinestetik</h3>
                      <p className="text-sm text-blue-700">Belajar dengan gerakan</p>
                    </div>
                  </div>
                </div>
                <Button 
                  onClick={() => setCurrentVakQuestion(1)}
                  className="w-full bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600 text-white text-lg py-4 rounded-xl"
                >
                  Mulai Tes Gaya Belajar
                </Button>
              </CardContent>
            </Card>

            <div className="text-center mt-8">
              <Button 
                onClick={() => { setCurrentPage('home'); setCurrentVakQuestion(0) }}
                className="bg-gray-500 hover:bg-gray-600 text-white text-lg px-6 py-3 rounded-xl"
              >
                ← Kembali
              </Button>
            </div>
          </div>

          <footer className="text-center mt-12 pb-8">
            <p className="text-purple-700 font-medium">
              Website ini dibuat oleh <strong>Teguh Gunawan Bahtiar</strong>
            </p>
            <p className="text-purple-600">
              Telegram: <a href="https://t.me/abughaisani" target="_blank" rel="noopener noreferrer" className="hover:underline">@abughaisani (t.me/abughaisani)</a>
            </p>
          </footer>
        </div>
      )
    }

    const question = vakQuestions[currentVakQuestion]
    const progress = ((currentVakQuestion + 1) / vakQuestions.length) * 100

    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-100 via-purple-100 to-pink-100 p-4">
        <div className="max-w-4xl mx-auto">
          <div className="mb-8">
            <div className="flex justify-between items-center mb-4">
              <h1 className="text-2xl md:text-3xl font-bold text-blue-800">
                🧠 Tes Gaya Belajar VAK
              </h1>
              <span className="text-lg font-medium text-blue-600">
                {currentVakQuestion + 1} / {vakQuestions.length}
              </span>
            </div>
            <Progress value={progress} className="h-3" />
          </div>

          <Card className="bg-white/80 backdrop-blur-sm border-2 border-blue-200">
            <CardHeader>
              <CardTitle className="text-xl text-blue-800">
                Pertanyaan {currentVakQuestion + 1}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-lg text-gray-800 mb-8">
                {question.text}
              </p>
              
              <div className="space-y-4">
                <Button 
                  onClick={() => handleVakAnswer(true)}
                  className="w-full bg-gradient-to-r from-green-400 to-green-500 hover:from-green-500 hover:to-green-600 text-white text-lg p-6 rounded-xl"
                >
                  ✓ Ya
                </Button>
                
                <Button 
                  onClick={() => handleVakAnswer(false)}
                  className="w-full bg-gradient-to-r from-red-400 to-red-500 hover:from-red-500 hover:to-red-600 text-white text-lg p-6 rounded-xl"
                >
                  ✗ Tidak
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        <footer className="text-center mt-12 pb-8">
          <p className="text-purple-700 font-medium">
            Website ini dibuat oleh <strong>Teguh Gunawan Bahtiar</strong>
          </p>
          <p className="text-purple-600">
            Telegram: <a href="https://t.me/abughaisani" target="_blank" rel="noopener noreferrer" className="hover:underline">@abughaisani (t.me/abughaisani)</a>
          </p>
        </footer>
      </div>
    )
  }

  const renderResultsPage = () => {
    const mbtiType = calculateMbtiType()
    const vakStyle = calculateVakStyle()
    const mbtiInfo = mbtiDescriptions[mbtiType]
    const vakInfo = getVakRecommendation(vakStyle)

    return (
      <div className="min-h-screen bg-gradient-to-br from-yellow-100 via-pink-100 to-purple-100 p-4">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-8">
            <div className="text-6xl mb-4">🎉</div>
            <h1 className="text-3xl md:text-4xl font-bold text-purple-800 mb-4">
              Hasil Tes Kepribadian & Gaya Belajar Kamu!
            </h1>
            <p className="text-xl text-purple-600">
              {studentName}, ini adalah hasil lengkap tes kepribadian dan gaya belajarmu:
            </p>
          </div>

          <div ref={resultsRef} className="bg-white rounded-2xl p-8 mb-8">
            {/* MBTI Results Section */}
            <div className="mb-12">
              <div className={`bg-gradient-to-r ${mbtiInfo.color} text-white p-6 rounded-2xl mb-6`}>
                <div className="text-center">
                  <div className="text-5xl mb-3">{mbtiInfo.emoji}</div>
                  <div className="text-4xl font-bold mb-2">{mbtiType}</div>
                  <div className="text-2xl">{mbtiInfo.title}</div>
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-6 mb-8">
                <Card className="border-2 border-purple-200">
                  <CardHeader>
                    <CardTitle className="text-xl text-purple-800 flex items-center gap-2">
                      🌟 Tentang Kamu
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-700 mb-4">{mbtiInfo.description}</p>
                    <p className="text-gray-700">{mbtiInfo.detailedDescription}</p>
                  </CardContent>
                </Card>

                <Card className="border-2 border-blue-200">
                  <CardHeader>
                    <CardTitle className="text-xl text-blue-800 flex items-center gap-2">
                      💪 Kekuatanmu
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-2">
                      {mbtiInfo.strengths.map((strength, index) => (
                        <li key={index} className="flex items-center gap-2">
                          <span className="text-green-500">✓</span>
                          <span className="text-gray-700">{strength}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              </div>

              <div className="grid md:grid-cols-2 gap-6 mb-8">
                <Card className="border-2 border-orange-200">
                  <CardHeader>
                    <CardTitle className="text-xl text-orange-800 flex items-center gap-2">
                      🎯 Profesi yang Cocok
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 gap-2">
                      {mbtiInfo.professions.map((profession, index) => (
                        <div key={index} className="bg-orange-50 p-3 rounded-lg text-center">
                          <span className="text-gray-800 font-medium">{profession}</span>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-2 border-red-200">
                  <CardHeader>
                    <CardTitle className="text-xl text-red-800 flex items-center gap-2">
                      ⚠️ Tantangan yang Perlu Diperhatikan
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-2">
                      {mbtiInfo.challenges.map((challenge, index) => (
                        <li key={index} className="flex items-center gap-2">
                          <span className="text-red-500">!</span>
                          <span className="text-gray-700">{challenge}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              </div>

              <Card className="border-2 border-green-200 mb-8">
                <CardHeader>
                  <CardTitle className="text-xl text-green-800 flex items-center gap-2">
                    📚 Cara Belajar Terbaik untuk {mbtiType}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-700 mb-6">{mbtiInfo.detailedLearning}</p>
                  <div className="grid md:grid-cols-2 gap-4">
                    {mbtiInfo.learningRecommendations.map((recommendation, index) => (
                      <div key={index} className="bg-green-50 p-4 rounded-lg">
                        <div className="flex items-start gap-3">
                          <span className="text-green-600 font-bold mt-1">{index + 1}.</span>
                          <span className="text-gray-700">{recommendation}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>

            <Separator className="my-8" />

            {/* VAK Results Section */}
            <div>
              <div className="bg-gradient-to-r from-blue-400 to-green-400 text-white p-6 rounded-2xl mb-6">
                <div className="text-center">
                  <div className="text-5xl mb-3">🧠</div>
                  <div className="text-3xl font-bold mb-2">{vakStyle}</div>
                  <div className="text-xl">{vakInfo.title}</div>
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-6 mb-8">
                <Card className="border-2 border-blue-200">
                  <CardHeader>
                    <CardTitle className="text-xl text-blue-800 flex items-center gap-2">
                      🎯 Gaya Belajarmu
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-700 mb-4">{vakInfo.description}</p>
                    <p className="text-gray-700">{vakInfo.detailedDescription}</p>
                  </CardContent>
                </Card>

                <Card className="border-2 border-green-200">
                  <CardHeader>
                    <CardTitle className="text-xl text-green-800 flex items-center gap-2">
                      📊 Skor VAK Kamu
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex justify-between items-center">
                        <span className="font-medium">Visual:</span>
                        <div className="flex items-center gap-2">
                          <div className="w-32 bg-gray-200 rounded-full h-3">
                            <div 
                              className="bg-red-500 h-3 rounded-full" 
                              style={{ width: `${(vakScores.V / 30) * 100}%` }}
                            ></div>
                          </div>
                          <span className="font-bold text-red-600">{vakScores.V}</span>
                        </div>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="font-medium">Auditori:</span>
                        <div className="flex items-center gap-2">
                          <div className="w-32 bg-gray-200 rounded-full h-3">
                            <div 
                              className="bg-green-500 h-3 rounded-full" 
                              style={{ width: `${(vakScores.A / 30) * 100}%` }}
                            ></div>
                          </div>
                          <span className="font-bold text-green-600">{vakScores.A}</span>
                        </div>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="font-medium">Kinestetik:</span>
                        <div className="flex items-center gap-2">
                          <div className="w-32 bg-gray-200 rounded-full h-3">
                            <div 
                              className="bg-blue-500 h-3 rounded-full" 
                              style={{ width: `${(vakScores.K / 30) * 100}%` }}
                            ></div>
                          </div>
                          <span className="font-bold text-blue-600">{vakScores.K}</span>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              <Card className="border-2 border-purple-200 mb-8">
                <CardHeader>
                  <CardTitle className="text-xl text-purple-800 flex items-center gap-2">
                    ✨ Karakteristik Pembelajar {vakStyle}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid md:grid-cols-2 gap-4">
                    {vakInfo.characteristics.map((characteristic, index) => (
                      <div key={index} className="bg-purple-50 p-4 rounded-lg">
                        <div className="flex items-start gap-3">
                          <span className="text-purple-600">•</span>
                          <span className="text-gray-700">{characteristic}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card className="border-2 border-yellow-200">
                <CardHeader>
                  <CardTitle className="text-xl text-yellow-800 flex items-center gap-2">
                    💡 Rekomendasi Belajar untuk {vakStyle}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid md:grid-cols-2 gap-4">
                    {vakInfo.recommendations.map((recommendation, index) => (
                      <div key={index} className="bg-yellow-50 p-4 rounded-lg">
                        <div className="flex items-start gap-3">
                          <span className="text-yellow-600 font-bold mt-1">{index + 1}.</span>
                          <span className="text-gray-700">{recommendation}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Action Buttons - Not included in PDF */}
          <div className="flex flex-wrap gap-4 justify-center mb-8">
            <Button 
              onClick={exportToPDF}
              className="bg-gradient-to-r from-red-500 to-pink-500 hover:from-red-600 hover:to-pink-600 text-white text-lg px-6 py-3 rounded-xl"
            >
              📄 Download PDF
            </Button>
            <Button 
              onClick={exportToJPG}
              className="bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600 text-white text-lg px-6 py-3 rounded-xl"
            >
              🖼️ Download JPG
            </Button>
            <Button 
              onClick={resetTest}
              className="bg-gradient-to-r from-green-500 to-teal-500 hover:from-green-600 hover:to-teal-600 text-white text-lg px-6 py-3 rounded-xl"
            >
              🔄 Tes Lagi
            </Button>
            <Button 
              onClick={() => setCurrentPage('home')}
              className="bg-gray-500 hover:bg-gray-600 text-white text-lg px-6 py-3 rounded-xl"
            >
              🏠 Menu Utama
            </Button>
          </div>

          <Card className="bg-gradient-to-br from-yellow-100 to-orange-100 border-2 border-yellow-300">
            <CardHeader>
              <CardTitle className="text-2xl text-orange-800 text-center">
                💡 Tips Sukses Belajar
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-3 gap-4">
                <div className="bg-white/80 p-4 rounded-xl text-center">
                  <div className="text-3xl mb-2">🎯</div>
                  <h3 className="font-bold text-orange-800 mb-2">Fokus pada Kekuatan</h3>
                  <p className="text-sm text-gray-700">Gunakan kelebihan kepribadianmu untuk belajar lebih efektif sesuai rekomendasi di atas</p>
                </div>
                <div className="bg-white/80 p-4 rounded-xl text-center">
                  <div className="text-3xl mb-2">🌱</div>
                  <h3 className="font-bold text-orange-800 mb-2">Kembangkan Diri</h3>
                  <p className="text-sm text-gray-700">Coba metode belajar baru untuk melatih area yang perlu diperbaiki</p>
                </div>
                <div className="bg-white/80 p-4 rounded-xl text-center">
                  <div className="text-3xl mb-2">🤝</div>
                  <h3 className="font-bold text-orange-800 mb-2">Kerja Sama</h3>
                  <p className="text-sm text-gray-700">Belajar dengan teman yang memiliki gaya belajar berbeda untuk saling melengkapi</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <footer className="text-center mt-12 pb-8">
          <p className="text-purple-700 font-medium">
            Website ini dibuat oleh <strong>Teguh Gunawan Bahtiar</strong>
          </p>
          <p className="text-purple-600">
            Telegram: <a href="https://t.me/abughaisani" target="_blank" rel="noopener noreferrer" className="hover:underline">@abughaisani (t.me/abughaisani)</a>
          </p>
        </footer>
      </div>
    )
  }

  return (
    <>
      {currentPage === 'home' && renderHomePage()}
      {currentPage === 'learn' && renderLearnPage()}
      {currentPage === 'dimension-detail' && renderDimensionDetailPage()}
      {currentPage === 'mbti-test' && renderMbtiTestPage()}
      {currentPage === 'vak-test' && renderVakTestPage()}
      {currentPage === 'results' && renderResultsPage()}
    </>
  )
}