import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Tes Kepribadian & Gaya Belajar Anak - MBTI & VAK",
  description: "Website edukasi untuk anak usia 6-12 tahun. Tes kepribadian MBTI dan gaya belajar VAK (Visual-Auditori-Kinestetik) dengan metode Quantum Teaching yang menyenangkan.",
  keywords: ["MBTI anak", "tes kepribadian anak", "gaya belajar VAK", "quantum teaching", "pendidikan anak", "tes psikologi anak"],
  authors: [{ name: "Teguh Gunawan Bahtiar" }],
  icons: {
    icon: "https://z-cdn.chatglm.cn/z-ai/static/logo.svg",
  },
  openGraph: {
    title: "Tes Kepribadian & Gaya Belajar Anak",
    description: "Kenali dirimu, temukan cara belajarmu, dan jadilah versi terbaikmu! Website edukasi untuk anak dengan MBTI dan VAK.",
    url: "https://chat.z.ai",
    siteName: "Tes Kepribadian Anak",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Tes Kepribadian & Gaya Belajar Anak",
    description: "Website edukasi untuk anak dengan MBTI dan VAK - Quantum Teaching",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
